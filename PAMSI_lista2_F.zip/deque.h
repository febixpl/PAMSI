#ifndef DEQUE
#define DEQUE
enum Stan {DequeEmptyException};
template <typename Object>
class PoleDeque{
public:
PoleDeque<Object> *pointerB=nullptr,*pointerN=nullptr;
Object dane;
};
template <typename Object>
class Deque {
PoleDeque<Object>* pointerF=nullptr,*pointerL=nullptr;
int ilosc=0;
public:
/**
* Zwraca ilość obiektów przechowywanych w deque
*/
int rozmiar() const{
return ilosc;
};
/**
* Zwraca true jeśli deque jest pusty
*/
bool isEmpty() const{
return !ilosc;
}
/**
* Zwraca pierwszy obiekt w deque.
* Wyrzuca DequeEmptyException jeśli deque jest pusty
*/
Object& pierwszy(){
if(isEmpty()){
throw(DequeEmptyException);
}
return pointerF->dane;
}
/**
* Zwraca ostatni obiekt w deque.
* Wyrzuca DequeEmptyException jeśli deque jest pusty
*/
Object& ostatni(){
if(isEmpty()){
throw(DequeEmptyException);
}
return pointerL->dane;
}
/**
* Dodaje obiekt do pocz ̧atku deque’a.
*/
Object& wstawPierwszy(const Object& obj){
if(isEmpty()){
pointerL=pointerF=new PoleDeque<Object>;
ilosc++;
pointerF->dane=obj;
}
else{
PoleDeque<Object>* pointertmp=pointerF;
pointerF=new PoleDeque<Object>;
ilosc++;
pointerF->pointerN=pointertmp;
pointertmp->pointerB=pointerF;
pointerF->dane=obj;
}
return pointerF->dane;
}
/**
* Usuwa pierwszy obiekt z deque.
* Wyrzuca DequeEmptyException jeśli deque jest pusty
*/

Object usunPierwszy(){
PoleDeque<Object>* pointertmp;
Object data;
if(isEmpty()){
throw(DequeEmptyException);}
data=pointerF->dane;
pointertmp=pointerF->pointerN;
pointertmp->pointerB=nullptr;
free(pointerF);
pointerF=pointertmp;
ilosc--;
return data;
}

/**
* Dodaje obiekt na końcu deque’a.
*/

Object& wstawOstatni(const Object& obj){
if(isEmpty()){
pointerF=pointerL=new PoleDeque<Object>;
ilosc++;
pointerL->dane=obj;
}
else{
PoleDeque<Object>* pointertmp=pointerL;
pointerL=new PoleDeque<Object>;
ilosc++;
pointerL->pointerB=pointertmp;
pointertmp->pointerN=pointerL;
pointerL->dane=obj;

}
return pointerL->dane;
}
/**
* Usuwa ostatni obiekt z deque.
* Wyrzuca DequeEmptyException jeśli deque jest pusty
*/

Object usunOstatni(){
PoleDeque<Object>* pointertmp;
Object data;
if(isEmpty()){
throw(DequeEmptyException);}
data=pointerL->dane;
pointertmp=pointerL->pointerB;
pointertmp->pointerN=nullptr;
free(pointerL);
pointerL=pointertmp;
ilosc--;
return data;
}
};
#endif
