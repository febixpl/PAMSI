#ifndef LISTA
#define LISTA
#include <iostream>
#include <fstream>

template <typename typ>
class PoleListy{
public:
PoleListy<typ> *pointer=nullptr;
typ dane;


};
template <typename typ>
class Lista{
PoleListy<typ>* pointer=nullptr;
int ilosc=0;

public:
typ& att(const int a);
bool add(typ data);
typ DeleteL(int a);
bool Wyswietl(std::ostream &StrWy);
int length(){return ilosc;}
bool DelateAll();
/*
//Miały być do 1 listy
bool odczyttex(const char* nameoffile);
bool odczyttex_bin(const char* nameoffile);
bool zapisztext(const char* nameoffile);
bool zapisztext_bin(const char* nameoffile);
bool List2Array(typ *tablica);
bool Array2List(typ const* tablica, const int rozmiar);
*/
};

template <typename typ>
bool Lista<typ>::add(typ data){
PoleListy<typ> *temp,*temp2; // wskazniki tymczasowe
if(pointer==nullptr){ // czy mamy jakies pola?
if(nullptr==(pointer=new PoleListy<typ>)){ //jak nie to już mamy
return false;}
pointer->dane=data; //wpisz coś
ilosc++; //obiektow
return true;
}
/*
if(pointer==nullptr){
if(nullptr==(pointer=new PoleListy<typ>)){
return false;}
pointer->dane=data;
ilosc++;
return true;
}
*/
else{
temp2=pointer; //wskaznik na 1 obiekt
temp=pointer->pointer; //to co jest w nim napisane

while(temp!=nullptr){ //czy jest tam info
temp2=temp;
temp=temp->pointer;
}//jeśli nie to
if(nullptr==(temp2->pointer=new PoleListy<typ>)){//wez wskaznik zapisany w 1 obiekcie i wpisz adres
return false;}
temp2->pointer->dane=data; // uzupełnij dane o obiekcie
ilosc++;}
return true;
}
template <typename typ>
typ& Lista<typ>::att(const int a){
PoleListy<typ> *temp;

temp=pointer;
for(int i=0;i<a;i++){
if(temp==nullptr){break;}
temp=temp->pointer;
}
return temp->dane;
}
template <typename typ>
typ Lista<typ>::DeleteL(int a){

PoleListy<typ>* temp,*temp2;
temp=pointer;
for(int i=0;i<a;i++){

if(temp==nullptr){return false;}
temp2=temp;
temp=temp->pointer;
}
if(temp==nullptr){return false;}
if(!a){
free(pointer);
ilosc--;
pointer=nullptr;
}
else{
temp2->pointer=temp->pointer;
free(temp);
ilosc--;
}
return true; }
template<typename typ>
bool Lista<typ>::Wyswietl(std::ostream &StrWy){
for(int i=0;i<length();i++){
StrWy<<att(i)<<' ';}
return true;
}
template <typename typ>
bool Lista<typ>::DelateAll(){
PoleListy<typ>* tmp=pointer,*tmp2;
while(tmp!=nullptr){
tmp2=tmp;
tmp=tmp->pointer;
free(tmp2);
}
ilosc=0;
return true;
}
/*
//Miały być do 1 listy
template <typename typ>
bool Lista<typ>::zapisztext(const char* nameoffile){
std::fstream plik(nameoffile,std::ios::out );
if(plik.is_open()){
for(int i=0;i<length();i++){
plik<<att(i);
}
plik.close();
return true;}
plik.close();
return false;
}
template <typename typ>
bool Lista<typ>::odczyttex(const char* nameoffile){
std::fstream plik(nameoffile,std::ios::in | std::ios::app);
if(plik.is_open()){
int ROZMIARDATA=20;
char buff[ROZMIARDATA];
 bool eof=false;
 do{
plik.read(buff,ROZMIARDATA);
//plik.close();
//plik.gcount();

for(int i=0;i<ROZMIARDATA;i++){

 //cout<<eof_n;
 if(i==plik.gcount() && plik.gcount()!=ROZMIARDATA){

 eof=true;
 break;}

add(buff[i]);
 }}
 while(!eof);
}
plik.close();
return true;}
template <typename typ>
bool Lista<typ>::zapisztext_bin(const char* nameoffile){
std::fstream plik(nameoffile,std::ios::binary | std::ios::out );
typ *buff=new typ[length()];
List2Array(buff);
if(plik.is_open()){
plik.write((char*)buff,length()*sizeof(typ));
plik.close();
free(buff);
return true;}
plik.close();
free(buff);
return false;
}
template <typename typ>
bool Lista<typ>::odczyttex_bin(const char* nameoffile){
std::fstream plik(nameoffile,std::ios::binary | std::ios::in | std::ios::app);
if(plik.is_open()){
int ROZMIARDATA=20;
char buff[ROZMIARDATA*sizeof(typ)];
 bool eof=false;
 typ *dane;
 do{
plik.read(buff,ROZMIARDATA*sizeof(typ));
//plik.close();
//plik.gcount();
dane=(typ*)buff;
for(int i=0;i<ROZMIARDATA;i++){

 //cout<<eof_n;
 if(i==plik.gcount() && plik.gcount()!=ROZMIARDATA){

 eof=true;
 break;}

add(dane[i]);
 }}
 while(!eof);
}
plik.close();
return true;
}
template <typename typ>
bool Lista<typ>::List2Array(typ *tablica){
for(int i=0;i<length();i++){
tablica[i]=att(i);
}
return true;
}
template <typename typ>
bool Lista<typ>::Array2List(typ const*const tablica,const int rozmiar){

for(int i=0;i<rozmiar;i++){
add(tablica[i]);
}
return true;
}
*/
#endif
