/*Michał Orczyk 226422
UWAGA!! progrem zgodny ze standardem c++11 "-std=c++11*/

#include <iostream>
#include <string>
#include "kolejka.h"
#include "lista.h"
#include "deque.h"
using namespace std;
string *palList;
int length_pal=0;
bool jestPal(const string testStr);
void Permutacja(string elements);
bool replace_m(string& wyraz,int i,int j);
bool CzyPalDeque(Deque<char>& testStr);
int Silnia(int x);
void usunDup();
int main(){
int d;
Lista<int> mylist;
Kolejka<int> mykolejka;
do{


cout<<"1. Permutacja\n\n"
<<"2. Wyswietl wyniki\n\n"
<<"3. Usun duplikaty\n\n"
<<"4. Lista\n\n"
<<"5. Kolejka\n\n"
<<"6. Czy palindrom\n\n"
<<"0. Koniec"<<endl;
cin>>d;

switch(d){
case 1:{
string elements;
cout<<"Podaj elementy\n\n";
cin>>elements;
length_pal=0;
palList=new string[Silnia(elements.length())];
Permutacja(elements);
break;
}
case 2:{
for(int i=0;i<length_pal;i++){
cout<<palList[i]<<endl;
}

break;}
case 3:{
usunDup();
break;}
case 4:{
int e;
do{
cout<<"1. Dodawanie do listy\n\n"
<<"2. Usuwanie pojedynczego elementu listy\n\n"
<<"3. Wyswietlanie zawartosci listy\n\n"
<<"4. Usuwanie wszystkiech elementów z listy\n\n"
<<"0. Powrot\n\n";
cin>>e;

switch(e){
case 1:{
int tmp;
cout<<"Wpisz liczbę: ";
cin>>tmp;
mylist.add(tmp);
break;}
case 2:{
int tmp;
cout<<"Ktory usunac?: ";
cin>>tmp;
mylist.DeleteL(tmp);
break;}
case 3:{
mylist.Wyswietl(cout);
cout<<endl;
break;}
case 4:{
char tmp;
cout<<"czy jestes pewien (y/n): ";
cin>>tmp;
if(tmp=='y'){
mylist.DelateAll();}
break;}
case 0:{break;}
default:{
cerr<<"Nie ma takiego polecenia";}
}
}while(e);
break;}
case 5:{
int e;
do{
cout<<"1. Dodawanie do kolejki\n\n"
<<"2. Usuwanie pojedynczego elementu z kolejki\n\n"
<<"3. Wyswietlanie zawartosci kolejki\n\n"
<<"4. Usuwanie wszystkiech elementów kolejki\n\n"
<<"0. Powrot\n\n";
cin>>e;

switch(e){
case 1:{
int tmp;
cout<<"Wpisz liczbę: ";
cin>>tmp;
mykolejka.enqueue(tmp);
break;}
case 2:{
cout<<mykolejka.dequeue()<<endl;
break;}
case 3:{
mykolejka.wyswietl(cout);
cout<<endl;
break;}
case 4:{
char tmp;
cout<<"czy jestes pewien (y/n): ";
cin>>tmp;
if(tmp=='y'){
mykolejka.delate_all();}
break;}
case 0:{break;}
default:{
cerr<<"Nie ma takiego polecenia";}
}
}while(e);
break;}
case 6:{
string wyraz;
Deque<char> WyrazD;
cout<<"Podaj Wyraz: ";
cin>>wyraz;
cout<<endl;
for(int i=0;i<wyraz.length();i++){
WyrazD.wstawOstatni(wyraz.at(i));
}
if(CzyPalDeque(WyrazD)){
cout<<"Jest palindromem\n\n";}
else{
cout<<"Nie jest palindromem\n\n";}
break;}
case 0:{break;}
default:{
cerr<<"Nie ma takiego polecenia\n\n";}
}}while(d);

return 0;
}

void Permutacja(string elements){
static int fran=0;

if(fran!=(signed)elements.length()){
for(int i=fran;i<(signed)elements.length();i++){
replace_m(elements,fran,i);
++fran;
Permutacja(elements);

--fran;
replace_m(elements,i,fran);
}

if(jestPal(elements) && fran==((signed)elements.length()-1)){
palList[length_pal++]=elements;
}
}
}

bool replace_m(string& wyraz,int i,int j){
char tmp=wyraz.at(j);
wyraz.at(j)=wyraz.at(i);
wyraz.at(i)=tmp;
return true;
}
int Silnia(int x){
int wynik;
if(x){
wynik=x*Silnia(x-1);
}
else{wynik=1;}
return wynik;}
void usunDup(){
for(int i=0;i<length_pal;i++){
for(int j=0;j<length_pal;j++){
if(palList[i]==palList[j] && i!=j){
//Usun element j
palList[j]=palList[length_pal-1];
--length_pal;
}
}
}
}

bool jestPal(const string testStr){


if(testStr.length()){
if(testStr[0]==testStr[testStr.length()-1]){


return jestPal(testStr.substr(1,testStr.length()-2));
}
else {return false;}
}
else {return true;}

}
bool CzyPalDeque(Deque<char>& testStr){
for(int i=0;i<(int)(testStr.rozmiar()/2);i++){
if(testStr.pierwszy()==testStr.ostatni()){
testStr.usunPierwszy();
testStr.usunOstatni();


return CzyPalDeque(testStr);
}
else {return false;}
}
return true;
}
