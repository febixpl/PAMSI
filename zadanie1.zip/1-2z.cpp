/*
Michał Orczyk 226422

*/



#include <iostream>
#include <string>
#include <cstdlib>
#include <time.h>
#include <fstream>

using namespace std;

int** TwTablicy(int,int);
bool Wyswietl( ostream& StrWy, int**const tablica,int,int);
int MaxWart(int**const,int,int);
bool WypLos(int** tablica,int maxi,int n,int m);

int Potega(int x, int p);
int Silnia(int x);
bool jestPal(const string testStr);
int main(){
   int n; //ilość wierszy
   int m; //ilość kolumn
  int opcja;
  int maxi;
  int** tablica;
char *Tablica;



  do{
  cout << "1.Wypełnianie tablicy wartosciam losowymi"<<endl;
  cout << "2.Wyświetlenie tablicy"<<endl;
   cout << "3.Maksymalna wartosc"<<endl;
cout << "4.Wczytywanie z pliku tekstowego"<<endl;
cout << "5.Zapisywanie do  pliku tekstowego"<<endl;
cout << "6.Wczytywanie z pliku binarnego"<<endl;
cout << "7.Zapisywanie do  pliku binarnego"<<endl;
 cout << "8.Silnia i Potega"<<endl;
 cout << "9.Czy jest palindromem"<<endl;

cout << "0.Koniec"<<endl;
cout << "Wybierz opcje"<<endl;
cin >> opcja;
 switch(opcja){


case 1: {
   cout<<endl<<"Podaj Wymiary n i m"<<endl;
     cin>>n>>m;
     tablica=TwTablicy(n,m);
cout<<endl<<"Podaj wartosc maksymalna"<<endl;
 cin>>maxi;
 WypLos(tablica,maxi,n,m);
break;}

 case 2: {
   Wyswietl(cout,tablica,n,m);
break;}
case 3: {cout<<endl<<MaxWart(tablica,n,m);break;}
 case 4:{

int ROZMIARDATA;
 string nazwa;
 cout<<"Podaj nazwe pliku: ";
 cin>>nazwa;
  cout<<"Podaj maksymalna ilosc znakow: ";
  cin>>ROZMIARDATA;
 // ROZMIARDATA++;
fstream plik(nazwa.c_str(),ios::in | ios::app);
if(plik.is_open()){

Tablica=new char[ROZMIARDATA];


plik.read(Tablica,ROZMIARDATA);
//plik.close();
//plik.gcount();


//Tablica[ROZMIARDATA]='\0';


char *buff=new char [plik.gcount()+1];
for(int i=0;i<plik.gcount();i++){
buff[i]=Tablica[i];}
buff[plik.gcount()]='\0';
cout<<buff<<endl;
free(buff);
free(Tablica);
plik.close();


}
 break;}
 case 5: {



int ROZMIARDATA;
 string nazwa;
 cout<<"Podaj nazwe pliku: ";
 cin>>nazwa;
  cout<<"Podaj ilosc znakow: ";
  cin>>ROZMIARDATA;
  Tablica = new char [ROZMIARDATA];
 cout<<"Wpisz dane:\n\n";
 for(int i=0;i<ROZMIARDATA || cin.eof();i++){
cin>>Tablica[i];}

fstream plik(nazwa.c_str(),std::ios::out );
if(plik.is_open()){
for(int i=0;i<ROZMIARDATA;i++){
plik<<Tablica[i];
}
free(Tablica);
plik.close();
}
 break;}
 case 6: {
int ROZMIARDATA;
 string nazwa;
 cout<<"Podaj nazwe pliku: ";
 cin>>nazwa;
  cout<<"Podaj maksymalna ilosc liczb: ";
  cin>>ROZMIARDATA;
 // ROZMIARDATA++;
fstream plik(nazwa.c_str(),ios::binary | ios::in | ios::app);
if(plik.is_open()){

Tablica=new char[ROZMIARDATA*sizeof(int)];


plik.read(Tablica,ROZMIARDATA*sizeof(int));
//plik.close();
//plik.gcount();


//Tablica[ROZMIARDATA]='\0';


char *buff=new char [plik.gcount()];
for(int i=0;i<plik.gcount();i++){
buff[i]=Tablica[i];}
int *dane=(int*)buff;


for(int i=0;i<((int)(plik.gcount()/sizeof(int)));i++){

cout<<dane[i]<<endl;}
free(buff);
free(Tablica);
plik.close();

}

cout<<endl;

 break;}

 case 7: {

 int ROZMIARDATA;
 string nazwa;
 cout<<"Podaj nazwe pliku: ";
 cin>>nazwa;
  cout<<"Podaj ilosc liczb: ";
  cin>>ROZMIARDATA;
  Tablica = new char [ROZMIARDATA*sizeof(int)];
 cout<<"Wpisz dane:\n\n";
 int* dane=(int*)Tablica;
 for(int i=0;i<ROZMIARDATA;i++){
cin>>dane[i];
}

fstream plik(nazwa.c_str(),ios::binary | std::ios::out );
if(plik.is_open()){
for(int i=0;i<(int)(ROZMIARDATA*sizeof(int));i++){
plik<<Tablica[i];
}
free(Tablica);
plik.close();
}
 break;}
 case 8: {
 int opj;
 cout<<"1.Silnia"<<endl<<"2.Potega"<<endl;
 cout << "Wybierz opcje"<<endl;
 cin>>opj;
 switch(opj){
 case 1: {int x;
 cout<<"Podaj x, gdzie x!"<<endl;
 cin>>x;
 cout<<"Wynik: "<<x<<"!="<<Silnia(x)<<endl;
 break;}

  case 2: {int x,p;
 cout<<"Podaj x i p, gdzie x^p"<<endl;
 cin>>x>>p;
 cout<<"Wynik: "<<x<<"^"<<p<<"="<<Potega(x,p)<<endl;
 break;}
  default : {cerr<<"Nie ma takiego polecenia";break;}

 }

break;}
 case 9: {
 string wyraz;
 cout<<"Wpisz slowo: ";
 cin>>wyraz;
 if(jestPal(wyraz)){
 cout<<"Jest palindromem"<<endl;}
 else{
 cout<<"Nie jest palindromem"<<endl;
 }
 break;}

 case 0: break;
 default : {cerr<<"Nie ma takiego polecenia";break;}
 }}while(opcja);

  return 0;
}
int** TwTablicy(int n,int m){
  int **tablica=new int* [n];

  for(int i=0;i<n;i++){
    tablica[i]= new int [m];}
  return tablica;
}
bool Wyswietl( ostream& StrWy, int**const tablica,int n,int m){
  for(int i=0;i<n;i++){
    for(int c=0;c<m;c++){
      StrWy<<tablica[i][c]<<' ';
      if(c>=m-1){
	StrWy<<endl;}}}
  return true;
}
int MaxWart(int**const tablica,int n,int m){
  int maxi=tablica[0][0];
  for(int i=0;i<n;i++){
    for(int c=0;c<m;c++){
      maxi=(tablica[i][c]>maxi)?tablica[i][c]:maxi;
    }}
  return maxi;
}
bool WypLos(int** tablica,int maxi,int n,int m){
  srand(time(NULL));
  for(int i=0;i<n;i++){
    for(int c=0;c<m;c++){
      tablica[i][c]=rand()%maxi+1;
    }}
  return true;
}
int Potega(int x, int p){
int wynik;
if(p){
wynik=x*Potega(x,p-1);}
else{ wynik=1;}
return wynik;
}
int Silnia(int x){
int wynik;
if(x){
wynik=x*Silnia(x-1);
}
else{wynik=1;}
return wynik;}
bool jestPal(const string testStr){
static int i;
if(i<(int)(testStr.length()/2)){
if(testStr.at(i)==testStr.at(testStr.length()-1-i)){
i++;
return jestPal(testStr);}
else {return false;}
}
else {return true;}

}


