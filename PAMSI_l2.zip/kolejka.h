#ifndef KOLEJKA
#define KOLEJKA

#include <iostream>
#include <fstream>

template <typename typ>
class PoleKolejki{
public:
PoleKolejki<typ> *pointer=nullptr;
typ dane;

};
template <typename typ>
class Kolejka{
PoleKolejki<typ>* pointerF=nullptr;
PoleKolejki<typ>* pointerL=nullptr;
int ilosc=0;

public:
bool enqueue(typ data);
typ dequeue();
bool wyswietl(std::ostream &StrWy);
int length(){return ilosc;}
bool delate_all();

};
template <typename typ>
bool Kolejka<typ>::enqueue(typ data){
if(pointerF==nullptr && pointerL==nullptr){
pointerF=pointerL=new PoleKolejki<typ>;
pointerF->dane=data;
}
else{
pointerL->pointer=new PoleKolejki<typ>;
pointerL=pointerL->pointer;
pointerL->dane=data;
}
ilosc++;
return true;
}
template <typename typ>
typ Kolejka<typ>::dequeue(){
PoleKolejki<typ>* pointertmp=pointerF;
typ tmp;
if(pointerF!=nullptr){
tmp=pointerF->dane;

pointerF=pointerF->pointer;
free(pointertmp);
ilosc--;
}
return tmp;}
template<typename typ>
bool Kolejka<typ>::wyswietl(std::ostream &StrWy){
PoleKolejki<typ> *pointertmp=pointerF;
while(pointertmp!=pointerL){
StrWy<<pointertmp->dane<<' ';;
pointertmp=pointertmp->pointer;}
if(pointertmp!=nullptr){
StrWy<<pointertmp->dane<<std::endl;}
return true;
}
template<typename typ>
bool Kolejka<typ>::delate_all(){
PoleKolejki<typ> *pointertmp=pointerF,*pointertmp2;
while(pointertmp!=pointerL){
pointertmp2=pointertmp;
pointertmp=pointertmp->pointer;
free(pointertmp2);}
free(pointertmp);
pointerF=pointerL=nullptr;
ilosc=0;
return true;

}

#endif
